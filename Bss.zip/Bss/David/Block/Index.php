<?php
namespace Bss\David\Block;
class Index extends \Magento\Framework\View\Element\Template
{

}